package com.mindtree.entity;

public class PlayerStats {

	int pid;
	String fullName;
	String playingRole;
	Data data;

	public PlayerStats() {
		
	}

	public PlayerStats(int pid, String fullName, String playingRole, Data data) {
		super();
		this.pid = pid;
		this.fullName = fullName;
		this.playingRole = playingRole;
		this.data = data;
	}


	public int getPid() {
		return pid;
	}


	public void setPid(int pid) {
		this.pid = pid;
	}


	public String getFullName() {
		return fullName;
	}


	public void setFullName(String fullName) {
		this.fullName = fullName;
	}


	public String getPlayingRole() {
		return playingRole;
	}


	public void setPlayingRole(String playingRole) {
		this.playingRole = playingRole;
	}


	public Data getData() {
		return data;
	}


	public void setData(Data data) {
		this.data = data;
	}

}
