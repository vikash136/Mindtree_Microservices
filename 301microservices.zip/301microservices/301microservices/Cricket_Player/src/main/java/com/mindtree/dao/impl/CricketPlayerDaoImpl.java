package com.mindtree.dao.impl;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mindtree.dao.CricketPlayerdao;
import com.mindtree.entity.Player;
import com.mindtree.repository.CricketPlayersRepository;

@Service
public class CricketPlayerDaoImpl implements CricketPlayerdao {

	@Autowired
	private CricketPlayersRepository cricketPlayersRepository;

	@Override
	public List<Player> getAllPlayerDetails() {
		return cricketPlayersRepository.findAll();
	}

	@Override
	public Optional<Player> getPlayerById(int playerId) {
		return cricketPlayersRepository.findById(playerId);
	}

	@Override
	public Player saveplayer(Player playerInfo) {
		return cricketPlayersRepository.save(playerInfo);
	}

	@Override
	public String deletePlayerById(int playerId) {
		Optional<Player> optPlayer = cricketPlayersRepository.findById(playerId);
		Player getPlayer = optPlayer.get();
		cricketPlayersRepository.delete(getPlayer);
		return "Player has been successfully removed!!";
	}
}
