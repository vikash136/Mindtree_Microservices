package com.mindtree.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.dao.CricketPlayerdao;
import com.mindtree.datasource.CricketPlayerDataSource;
import com.mindtree.entity.Player;
import com.mindtree.service.CricketPlayerService;

@Service
public class CricketPlayerserviceImpl implements CricketPlayerService {

	@Autowired
	private CricketPlayerdao cricketPlayerdao;

	@Autowired
	CricketPlayerDataSource cricketPlayerDataSource;

	@Override
	public List<Player> getAllPlayerDetails() {
		List<Player> allPlayers = cricketPlayerdao.getAllPlayerDetails();
		return allPlayers;
	}

	@Override
	public Optional<Player> getPlayerById(int playerId) {
		return cricketPlayerdao.getPlayerById(playerId);
	}

	@Override
	public Player saveplayer(int playerId) {
		Player playerInfo = cricketPlayerDataSource.getCricketPlayerInfo(playerId);
		return cricketPlayerdao.saveplayer(playerInfo);
	}

	@Override
	public String deletePlayerById(int playerId) {
		return cricketPlayerdao.deletePlayerById(playerId);
	}

}