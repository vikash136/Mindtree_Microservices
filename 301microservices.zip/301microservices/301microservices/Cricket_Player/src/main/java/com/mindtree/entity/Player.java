package com.mindtree.entity;
import javax.persistence.Entity;
import javax.persistence.Id;



@Entity
//@RedisHash
public class Player {

	@Id
	int playerId;
	String name;
	String category;
	int numOfMatchesPlayed;
	int fifties;
	int hundreds;
	int wickets;

	public Player() {

	}

	public int getPlayerId() {
		return playerId;
	}

	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public int getNumOfMatchesPlayed() {
		return numOfMatchesPlayed;
	}

	public void setNumOfMatchesPlayed(int numOfMatchesPlayed) {
		this.numOfMatchesPlayed = numOfMatchesPlayed;
	}

	public int getFifties() {
		return fifties;
	}

	public void setFifties(int fifties) {
		this.fifties = fifties;
	}

	public int getHundreds() {
		return hundreds;
	}

	public void setHundreds(int hundreds) {
		this.hundreds = hundreds;
	}

	public int getWickets() {
		return wickets;
	}

	public void setWickets(int wickets) {
		this.wickets = wickets;
	}
}
