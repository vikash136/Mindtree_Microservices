package com.mindtree.datasource;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.mindtree.entity.Player;
import com.mindtree.entity.PlayerStats;

@Component
public class CricketPlayerDataSource {

	@Value("${api.key}")
	private String apikey;
	private Logger LOG = Logger.getLogger(CricketPlayerDataSource.class);
	private String url = "https://cricapi.com/api/playerStats";

	@Autowired
	private RestTemplate restTemplate;
	 public Player getCricketPlayerInfo(int playerId)
	    {
	        //logger.info("Inside Player Info");
	        PlayerStats playerSummary =restTemplate.getForObject(url+"?apikey="+apikey+"&pid="+playerId,PlayerStats.class);
	       System.out.println("player summry   "+playerSummary);
	        int numOfMatchesPlayed=Integer.parseInt((playerSummary.getData().getBowling().getListA().getMat()))
	                +Integer.parseInt((playerSummary.getData().getBowling().getFirstClass().getMat()))
	                +Integer.parseInt((playerSummary.getData().getBowling().getODIs().getMat()))
	                +Integer.parseInt((playerSummary.getData().getBowling().getT20Is().getMat()))
	                +Integer.parseInt((playerSummary.getData().getBowling().getTests().getMat()))
	                +Integer.parseInt((playerSummary.getData().getBatting().getListA().getMat()))
	                +Integer.parseInt((playerSummary.getData().getBatting().getFirstClass().getMat()))
	                +Integer.parseInt((playerSummary.getData().getBatting().getODIs().getMat()))
	                +Integer.parseInt((playerSummary.getData().getBatting().getT20Is().getMat()))
	                +Integer.parseInt((playerSummary.getData().getBatting().getTests().getMat()));
	       
	        int wickets = Integer.parseInt((playerSummary.getData().getBowling().getListA().getWkts()))
	                +Integer.parseInt((playerSummary.getData().getBowling().getFirstClass().getWkts()))
	                +Integer.parseInt((playerSummary.getData().getBowling().getODIs().getWkts()))
	                +Integer.parseInt((playerSummary.getData().getBowling().getT20Is().getWkts()))
	                +Integer.parseInt((playerSummary.getData().getBowling().getTests().getWkts()));
	       
	        int fifties = Integer.parseInt((playerSummary.getData().getBatting().getListA().get50()))
	                +Integer.parseInt((playerSummary.getData().getBatting().getFirstClass().get50()))
	                +Integer.parseInt((playerSummary.getData().getBatting().getODIs().get50()))
	                +Integer.parseInt((playerSummary.getData().getBatting().getT20Is().get50()))
	                +Integer.parseInt((playerSummary.getData().getBatting().getTests().get50()));
	       
	        int hundreds = Integer.parseInt((playerSummary.getData().getBatting().getListA().get100()))
	                +Integer.parseInt((playerSummary.getData().getBatting().getFirstClass().get100()))
	                +Integer.parseInt((playerSummary.getData().getBatting().getODIs().get100()))
	                +Integer.parseInt((playerSummary.getData().getBatting().getT20Is().get100()))
	                +Integer.parseInt((playerSummary.getData().getBatting().getTests().get100()));
	       
	        Player player=new Player();
	        player.setPlayerId(playerId);
	        player.setName(playerSummary.getFullName());
	        player.setCategory(playerSummary.getPlayingRole());
	        player.setNumOfMatchesPlayed(numOfMatchesPlayed);
	        player.setFifties(fifties);
	        player.setHundreds(hundreds);
	        player.setWickets(wickets);
	        return player;
	    }

}