package com.mindtree.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.mindtree.entity.Player;

@Service
public interface CricketPlayerdao {

	public List<Player> getAllPlayerDetails();

	public Optional<Player> getPlayerById(int playerId);

	public Player saveplayer(Player playerInfo);

	public String deletePlayerById(int playerId);
}
