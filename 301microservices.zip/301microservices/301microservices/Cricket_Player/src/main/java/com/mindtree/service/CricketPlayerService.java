package com.mindtree.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.mindtree.entity.Player;

@Service
public interface CricketPlayerService {

	public List<Player> getAllPlayerDetails();

	public Optional<Player> getPlayerById(int playerId);

	public Player saveplayer(int playerId);

	public String deletePlayerById(int playerId);

}
