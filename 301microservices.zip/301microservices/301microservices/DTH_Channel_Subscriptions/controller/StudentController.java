package com.mindtree.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.entity.Student;
import com.mindtree.service.StudentService;


@RestController


public class StudentController
{


	
	@Autowired
	// by difault get
	private StudentService studentService;
	@RequestMapping(value="/student")
	public List<Student>getAllStudent()
	{
		return studentService.getAllStudent();	
	}
	
	
	@RequestMapping(value="/student/{s_id}")
	public Student getStudent( @PathVariable int s_id)
	{
		return studentService.getStudent(s_id);
		
	}

	
	//post method
	
	@RequestMapping(method=RequestMethod.POST,value="/student")
	public void addStudent(@RequestBody Student student)
	{
		studentService.addStudent(student);
	}
	
	//update method
	
		@RequestMapping(method=RequestMethod.PUT,value="student/{s_id}")
		public void updateStudent(@RequestBody Student student,@PathVariable int s_id)
		{
			studentService.updateStudent(s_id,student);
		}
		
		
		
		//delete method
		@RequestMapping(method=RequestMethod.DELETE,value="student/{s_id}")
		public void deleteStudent(@PathVariable int s_id)
		{
			studentService.deleteStudent(s_id);
		}
		
		
		
		
		
		
		
		
		
		
		
}
