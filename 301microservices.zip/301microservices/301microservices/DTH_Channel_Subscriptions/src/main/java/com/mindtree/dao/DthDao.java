package com.mindtree.dao;

import java.math.BigInteger;
import java.util.List;

import com.mindtree.entity.Channels;
import com.mindtree.entity.Subscription_Channel;

public interface DthDao {

	String SubscribeChannel(Subscription_Channel subscribed_channel);

	String UnSubscribeChannel(BigInteger subscriptionId, int subscriptionChannelID);

	String getCustomerById(BigInteger subscriptionId3);

	double getTotalSubscriptionCost(List<Channels> subscribedChannelList);

	List<Channels> viewSubscriptionDetails(BigInteger subscriptionId3);

}
