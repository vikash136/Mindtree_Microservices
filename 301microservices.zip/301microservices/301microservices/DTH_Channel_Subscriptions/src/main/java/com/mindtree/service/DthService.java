package com.mindtree.service;

import java.math.BigInteger;
import java.time.LocalDate;
import java.util.List;

import com.mindtree.entity.Channels;

public interface DthService {

	String SubscribeChannel(BigInteger subscriptionId, int subscriptionChannelID, LocalDate subscriptionDate);

	String UnSubscribeChannel(BigInteger subscriptionId1, int subscriptionChannelID1);

	String getCustomerById(BigInteger subscriptionId3);

	List<Channels> viewSubscriptionDetails(BigInteger subscriptionId3);

	double getTotalSubscriptionCost(List<Channels> channels_list);

}
