package com.mindtree.entity;

import java.math.BigInteger;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="SUBSCRIPTION_CHANNEL")
public class Subscription_Channel {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private int id;
	
	@Column(name="SUBSCRIBER_DATE")
	private LocalDate subscriptionDate;
	
	@Column(name="CHANNEL_ID")
	private int channelId;
	
	@Column(name="SUBSCRIBER_ID")
	private BigInteger subscriptionId;

	public Subscription_Channel() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Subscription_Channel(int id, LocalDate subscriptionDate, int channelId, BigInteger subscriptionId) {
		this.id = id;
		this.subscriptionDate = subscriptionDate;
		this.channelId = channelId;
		this.subscriptionId = subscriptionId;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public LocalDate getSubscriptionDate() {
		return subscriptionDate;
	}

	public void setSubscriptionDate(LocalDate subscriptionDate) {
		this.subscriptionDate = subscriptionDate;
	}

	public int getChannelId() {
		return channelId;
	}

	public void setChannelId(int channelId) {
		this.channelId = channelId;
	}

	public BigInteger getSubscriptionId() {
		return subscriptionId;
	}

	public void setSubscriptionId(BigInteger subscriptionId) {
		this.subscriptionId = subscriptionId;
	}

	
	
}
