package com.mindtree.service.impl;

import java.math.BigInteger;
import java.time.LocalDate;
import java.util.List;

import com.mindtree.dao.DthDao;
import com.mindtree.dao.impl.DthDaoImpl;
import com.mindtree.entity.Channels;
import com.mindtree.entity.Subscription_Channel;
import com.mindtree.service.DthService;

public class DthServiceImpl implements DthService {

	DthDao  dthDao= new DthDaoImpl();
	public String SubscribeChannel(BigInteger subscriptionId, int subscriptionChannelID, LocalDate subscriptionDate) {
		
		Subscription_Channel subscribed_channel=new Subscription_Channel();
		subscribed_channel.setSubscriptionId(subscriptionId);
		subscribed_channel.setChannelId(subscriptionChannelID);
		subscribed_channel.setSubscriptionDate(subscriptionDate);
		return dthDao.SubscribeChannel(subscribed_channel);
	}

	public String UnSubscribeChannel(BigInteger subscriptionId, int subscriptionChannelID) {
		return dthDao.UnSubscribeChannel(subscriptionId,subscriptionChannelID);
	}

	public String getCustomerById(BigInteger subscriptionId3) {
		return dthDao.getCustomerById(subscriptionId3);
	}


	public double getTotalSubscriptionCost(List<Channels> subscribedChannelList) {
		return dthDao.getTotalSubscriptionCost(subscribedChannelList);
	}
	
	public List<Channels> viewSubscriptionDetails(BigInteger subscriptionId3) {
		return dthDao.viewSubscriptionDetails(subscriptionId3);
	}
}
