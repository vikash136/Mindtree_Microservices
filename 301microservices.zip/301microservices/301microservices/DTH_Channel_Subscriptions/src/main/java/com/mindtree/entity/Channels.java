package com.mindtree.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "CHANNEL")
public class Channels {

	@Id
	@Column(name = "CHANNEL_ID")
	private int channelID;

	@Column(name = "CHANNEL_NAME")
	private String channelName;

	@Column(name = "COST_COST")
	private double channelCost;

	public int getChannelID() {
		return channelID;
	}

	public void setChannelID(int channelID) {
		this.channelID = channelID;
	}

	public String getChannelName() {
		return channelName;
	}

	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}

	public double getChannelCost() {
		return channelCost;
	}

	public void setChannelCost(double channelCost) {
		this.channelCost = channelCost;
	}

}
