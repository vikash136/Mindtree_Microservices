package com.mindtree.entity;


import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name="CUSTOMER")
public class Customers {

	@Id
	@Column(name="SUBSCRIBER_ID")
	private String subscriberID;

	@Column(name="REGISTERED_MOBILE")
	private String registerdMobile;

	@Column(name="FIRST_NAME")
	private String fristName;

	@Column(name="LAST_NAME")
	private String lastName;
	
	@OneToMany
	private Collection<Channels>channel=new ArrayList<Channels>();

	
	public Customers() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Customers(String subscriberID, String registerdMobile, String fristName, String lastName,
			Collection<Channels> channel) {
		this.subscriberID = subscriberID;
		this.registerdMobile = registerdMobile;
		this.fristName = fristName;
		this.lastName = lastName;
		this.channel = channel;
	}


	public String getSubscriberID() {
		return subscriberID;
	}


	public void setSubscriberID(String subscriberID) {
		this.subscriberID = subscriberID;
	}


	public String getRegisterdMobile() {
		return registerdMobile;
	}


	public void setRegisterdMobile(String registerdMobile) {
		this.registerdMobile = registerdMobile;
	}


	public String getFristName() {
		return fristName;
	}


	public void setFristName(String fristName) {
		this.fristName = fristName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public Collection<Channels> getChannel() {
		return channel;
	}


	public void setChannel(Collection<Channels> channel) {
		this.channel = channel;
	}

	
}
