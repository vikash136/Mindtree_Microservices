package com.mindtree;

import java.math.BigInteger;
import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.mindtree.entity.Channels;
import com.mindtree.service.DthService;
import com.mindtree.service.impl.DthServiceImpl;

@SpringBootApplication
public class DthChannelApplication {

    static Scanner scanner=new Scanner(System.in);
    
    public static void main(String[] args) {
        DthService dthService = new DthServiceImpl();
        
        while(true) {
            System.out.println("1. To subscribe the channels");
            System.out.println("2. To edit your subscription");
            System.out.println("3. To view your subscription details");
            System.out.println("4. To exit\n");
            
            System.out.println("Enter your choice :");
            switch(scanner.nextInt()) {
            
                case 1:    System.out.println("Enter subscriber id:");
                        BigInteger subscriptionId = scanner.nextBigInteger();
                        
                        System.out.println("Enter channel ID to subscribe:");
                        int subscriptionChannelID = scanner.nextInt();
                        
                        LocalDate subscriptionDate = LocalDate.now();
                        
                        String subscription = dthService.SubscribeChannel(subscriptionId,subscriptionChannelID,subscriptionDate);
                        
                        if(subscription.equals(null))    {
                            System.out.println("\nSubscription failed....try again\n");
                        } else {
                            System.out.println("\nChannel subscription successfull!!\n");
                        }
            
                        break;

 

                case 2:    System.out.println("Enter subscriber id:");
                        BigInteger subscriptionId1 = scanner.nextBigInteger();
                        
                        System.out.println("Enter channel ID to unsubscribe:");
                        int subscriptionChannelID1 = scanner.nextInt();
                        
                        String unsubscription = dthService.UnSubscribeChannel(subscriptionId1,subscriptionChannelID1);
                        
                        if(unsubscription.equals(null))    {
                            System.out.println("\nUnsubscription failed!! try again\n");
                        } else {
                            System.out.println("\nYou have successfully unsubscribed the channel!!\n");
                        }
                        
                        break;
                        
                case 3:    System.out.println("Enter subscriber ID to view the details:");
                        BigInteger subscriptionId3=scanner.nextBigInteger();
                        String customerName = dthService.getCustomerById(subscriptionId3);
                        List<Channels> channels_list = dthService.viewSubscriptionDetails(subscriptionId3);
                        double totalCost = dthService.getTotalSubscriptionCost(channels_list);
                        
                        System.out.println();
                        System.out.println("Your subscription details are :");
                        System.out.println("===============================");

 

                        System.out.println("Customer Name : " + customerName);
                        
                        System.out.println("Subscription ID : " + subscriptionId3);
                        
                        System.out.println("Channels subscribed for :");
                        System.out.println("===========================");
                        System.out.println("CHANNEL_NAME  CHANNEL_COST" );
                        System.out.println("===========================");
                        
                        if(channels_list.isEmpty()) {
                            System.out.println("Not subscribed to any channels!! Please subscribe now");
                        }

 

                        for(Channels channel : channels_list) {
                            System.out.println(channel.getChannelName() + "|" + channel.getChannelCost());
                        }
                        
                        /*for(int i = 0; i < channels_list.size(); i++) {
                            System.out.println(channels_list.get(i).getChannelName() + " " + channels_list.get(i).getChannelCost());
                        }*/
                            
                        System.out.println();
                        System.out.println("Total Subscription Cost : " + totalCost);
                        System.out.println();
                        
                        break;
                        
                case 4:    System.exit(0);
                
                default:System.out.print("Invalid choice...Try again");
                        break;

 

            }
        }
        
    }
    
}