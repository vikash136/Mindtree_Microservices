package com.mindtree.dth.utils;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class DthUtils {

	private static SessionFactory sf;

	public static SessionFactory getSessionFactory() {
		return new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(com.mindtree.entity.Channels.class)
				.addAnnotatedClass(com.mindtree.entity.Subscription_Channel.class)
				.addAnnotatedClass(com.mindtree.entity.Customers.class).buildSessionFactory();
	}
}
