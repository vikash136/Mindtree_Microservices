package com.mindtree.dao.impl;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.mindtree.dao.DthDao;
import com.mindtree.dth.utils.DthUtils;
import com.mindtree.entity.Channels;
import com.mindtree.entity.Customers;
import com.mindtree.entity.Subscription_Channel;

public class DthDaoImpl implements DthDao {
	
	public String SubscribeChannel(Subscription_Channel subscribed_channel) {
		final Session session = DthUtils.getSessionFactory().openSession();
		Transaction transaction = null;
		transaction = session.beginTransaction();
		session.save(subscribed_channel);
		transaction.commit();
		return "success";
	}

	public String UnSubscribeChannel(BigInteger subscriptionId, int subscriptionChannelID) {
		final Session session = DthUtils.getSessionFactory().openSession();
		Transaction transaction = session.beginTransaction();
		Query query = session.createQuery("delete from com.dth.entity.Subscription_channel where SUBSCRIBER_ID=:SUBSCRIBER_ID and CHANNEL_ID=:CHANNEL_ID");
		query.setParameter("SUBSCRIBER_ID", subscriptionId);
		query.setParameter("CHANNEL_ID", subscriptionChannelID);
		query.executeUpdate();
		transaction.commit();
		return "success";
	}

	public String getCustomerById(BigInteger subscriptionId3) {
		final Session session = DthUtils.getSessionFactory().openSession();
		Transaction transaction = null;
		transaction = session.beginTransaction();
		Customers foundCustomer = session.load(Customers.class, subscriptionId3);
		return foundCustomer.getFristName() + " " + foundCustomer.getLastName();
	}

	public List<Channels> viewSubscriptionDetails(BigInteger subscriptionId3) {
		final Session session = DthUtils.getSessionFactory().openSession();
		List<Integer> subscribedChannelIds = new ArrayList<>();
		List<Channels> subscribedChannels = new ArrayList<>();
		@SuppressWarnings("unchecked")
		List<Subscription_Channel> subscribedChannelList = session.createQuery("from com.dth.entity.Subscription_channel where SUBSCRIBER_ID='"+subscriptionId3+"'").list();
		for(Subscription_Channel channel : subscribedChannelList) {
				subscribedChannelIds.add(channel.getChannelId());						//adding result channel IDs to subscribedChannelIds list
		}
		for(Integer channelId : subscribedChannelIds) {
			Channels ch = session.get(Channels.class, channelId);		//getting channel object by result channel IDs in subscribedChannelIds list
			subscribedChannels.add(ch);									//adding those channel objects to subscribedChannels list
		}
		return subscribedChannels;
	}

	public double getTotalSubscriptionCost(List<Channels> subscribedChannelList) {
		double totalcost = 0.0;
		for(Channels channel : subscribedChannelList) {
			totalcost += channel.getChannelCost();
		}
		return 100.0 + totalcost;
	}
	
}
