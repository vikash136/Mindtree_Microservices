package com.mindtree.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Employee")
public class Employee {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int mId;
	private String employeeName;
	private Date hireDate;
	private String dept;
	
	@OneToMany(mappedBy = "loggedBy", cascade = CascadeType.ALL)
	private List<Ticket> ticketListOne;
	@OneToMany(mappedBy = "receivedBy", cascade = CascadeType.ALL)
	private List<Ticket> ticketListTwo;
	public int getmId() {
		return mId;
	}
	public void setmId(int mId) {
		this.mId = mId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public Date getHireDate() {
		return hireDate;
	}
	public void setHireDate(Date hireDate) {
		this.hireDate = hireDate;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public List<Ticket> getTicketListOne() {
		return ticketListOne;
	}
	public void setTicketListOne(List<Ticket> ticketListOne) {
		this.ticketListOne = ticketListOne;
	}
	public List<Ticket> getTicketListTwo() {
		return ticketListTwo;
	}
	public void setTicketListTwo(List<Ticket> ticketListTwo) {
		this.ticketListTwo = ticketListTwo;
	}

	
}
