package com.mindtree.employee.dao;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;

import com.mindtree.entity.Employee;
import com.mindtree.exception.EmployeeBadException;
import com.mindtree.exception.EmployeeNotFoundException;

public interface EmployeeDao {

	public List<Employee> getAllEmployee() throws  EmployeeBadException;

	public Optional<Employee> findByEmployeeId(String employeeId) throws EmployeeNotFoundException;

	public Boolean insertEmployeeData(@Valid Employee employee) throws  EmployeeBadException;

	public Boolean deleteEmployeeRecord(String employeeId) throws  EmployeeBadException;
}
