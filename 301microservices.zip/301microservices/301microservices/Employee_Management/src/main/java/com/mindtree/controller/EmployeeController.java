package com.mindtree.controller;

import javax.validation.Valid;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.entity.Employee;
import com.mindtree.exception.EmployeeBadException;
import com.mindtree.exception.EmployeeNotFoundException;
import com.mindtree.service.EmployeeService;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	private Logger LOG = Logger.getLogger(EmployeeController.class);

	@RequestMapping(value = "/employeeAll", method = RequestMethod.GET)
	public ResponseEntity<?> getAllEmployee() throws EmployeeNotFoundException, EmployeeBadException {
		LOG.debug("====Get all Employee data ====");
		return employeeService.getAllEmployee();
	}

	@RequestMapping(value = "/employeeId/{employeeId}", method = RequestMethod.GET)
	public ResponseEntity<?> findByEmployeeId(@PathVariable(value = "employeeId") String employeeId)
			throws EmployeeNotFoundException {
		LOG.debug("====Get all  data  from Employee Id ====");
		return employeeService.findByEmployeeId(employeeId);
	}

	@RequestMapping(value = "/addNewEmployeeDetails", method = RequestMethod.POST)
	public ResponseEntity<?> insertEmployeeData(@Valid @RequestBody Employee employee)
			throws EmployeeNotFoundException, EmployeeBadException {
		LOG.debug("====Insert Employee data ====");
		return employeeService.insertEmployeeData(employee);

	}

	@RequestMapping(value = "/delete/{employeeId}", method = RequestMethod.DELETE)
	public ResponseEntity<?> deleteEmployeeRecord(@PathVariable(value = "employeeId") String employeeId)
			throws EmployeeNotFoundException, EmployeeBadException {
		LOG.debug("====Delete Employee data  from Employee ID ====");
		return employeeService.deleteEmployeeRecord(employeeId);
	}
}
