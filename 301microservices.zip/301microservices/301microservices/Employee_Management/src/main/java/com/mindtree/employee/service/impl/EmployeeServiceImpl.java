package com.mindtree.employee.service.impl;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.mindtree.employee.dao.EmployeeDao;
import com.mindtree.entity.Employee;
import com.mindtree.exception.EmployeeBadException;
import com.mindtree.exception.EmployeeNotFoundException;
import com.mindtree.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeDao employeeDao;

	@Override
	public ResponseEntity<?> getAllEmployee() throws EmployeeBadException {

		List<Employee> allEmployee = employeeDao.getAllEmployee();

		if (!CollectionUtils.isEmpty(allEmployee)) {
			return new ResponseEntity<>(allEmployee, HttpStatus.OK);
		} else {
			throw new EmployeeBadException("Could not find data please try again later");
		}
	}

	@Override
	public ResponseEntity<?> findByEmployeeId(String employeeId) throws EmployeeNotFoundException {

		Optional<Employee> employeeObjectId = employeeDao.findByEmployeeId(employeeId);
		if (employeeObjectId.isPresent()) {
			return new ResponseEntity<>(employeeObjectId.get(), HttpStatus.OK);
		} else {
			throw new EmployeeNotFoundException(
					"MIght be you're entered duplicate dat, please try again with new employee info.");
		}
	}

	@Override
	public ResponseEntity<?> insertEmployeeData(@Valid Employee employee)
			throws EmployeeBadException, EmployeeNotFoundException {
		Optional<Employee> emp = employeeDao.findByEmployeeId(employee.getEmployeeId());

		if (emp.isPresent()) {
			throw new EmployeeBadException("User is already exist, PLease try again with different Id.");
		} else {
			if (employeeDao.insertEmployeeData(employee)) {
				return new ResponseEntity<>("Employee data saved successfully!!", HttpStatus.CREATED);
			}
		}
		throw new EmployeeBadException("Unable to save employee details");
	}

	@Override
	public ResponseEntity<?> deleteEmployeeRecord(String employeeId)
			throws EmployeeBadException, EmployeeNotFoundException {
		Optional<Employee> emp1 = employeeDao.findByEmployeeId(employeeId);
		if (emp1.isPresent()) {
			if (employeeDao.deleteEmployeeRecord(employeeId)) {
				return new ResponseEntity<>("Employee information has been deleted.", HttpStatus.NO_CONTENT);
			}
		}
		throw new EmployeeBadException("Unable to deletee employee information . Please try after sometime!!");
	}
}
