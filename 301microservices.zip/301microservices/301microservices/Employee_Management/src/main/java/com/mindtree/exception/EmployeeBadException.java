package com.mindtree.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class EmployeeBadException extends Exception {

	public EmployeeBadException(String exception) {
		super(exception);
	}
}
