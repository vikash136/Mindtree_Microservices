package com.mindtree.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class ExceptionHandler extends ResponseEntityExceptionHandler {

	@org.springframework.web.bind.annotation.ExceptionHandler(EmployeeNotFoundException.class)
	public final ResponseEntity<ExceptionResponse> handleUserNotFoundException(ExceptionResponse ex) {
		return new ResponseEntity(new ExceptionResponse(ex.getMessage()), HttpStatus.NOT_FOUND);
	}

	@org.springframework.web.bind.annotation.ExceptionHandler(EmployeeBadException.class)
	public final ResponseEntity<ExceptionResponse> handleBadRequestException(ExceptionResponse ex) {
		return new ResponseEntity(new ExceptionResponse(ex.getMessage()), HttpStatus.BAD_REQUEST);
	}
}