package com.mindtree.service;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.mindtree.entity.Employee;
import com.mindtree.exception.EmployeeBadException;
import com.mindtree.exception.EmployeeNotFoundException;

@Service
public interface EmployeeService {

	public ResponseEntity<?> getAllEmployee() throws  EmployeeBadException;
	
	public ResponseEntity<?> findByEmployeeId(String employeeId) throws EmployeeNotFoundException;

	public ResponseEntity<?> insertEmployeeData(@Valid Employee employee) throws  EmployeeBadException, EmployeeNotFoundException;

	public ResponseEntity<?> deleteEmployeeRecord(String employeeId) throws EmployeeBadException, EmployeeNotFoundException;

}
