package com.mindtree.employee.dao.impl;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.employee.dao.EmployeeDao;
import com.mindtree.employee.repository.EmployeeRepository;
import com.mindtree.entity.Employee;
import com.mindtree.exception.EmployeeBadException;
import com.mindtree.exception.EmployeeNotFoundException;

@Service
public class EmployeeDaoImpl implements EmployeeDao {

	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public List<Employee> getAllEmployee() throws EmployeeBadException {
		try {
			return employeeRepository.findAll();
		} catch (Exception e) {
			throw new EmployeeBadException("Could not find data please try again later");
		}
	}

	@Override
	public Optional<Employee> findByEmployeeId(String employeeId) throws EmployeeNotFoundException {
		try {
			return employeeRepository.findById(employeeId);
		} catch (Exception e) {
			throw new EmployeeNotFoundException(
					"MIght be you're entered duplicate data, please try again with new employee info.");
		}
	}

	@Override
	public Boolean insertEmployeeData(@Valid Employee employee) throws EmployeeBadException {
		try {
			Employee savedEmployee = employeeRepository.save(employee);
			return true;
		} catch (Exception e) {
			throw new EmployeeBadException("Unable to save employee details");
		}
	}

	@Override
	public Boolean deleteEmployeeRecord(String employeeId) throws EmployeeBadException {
		try {
			employeeRepository.deleteById(employeeId);
			return true;
		} catch (Exception e) {
			throw new EmployeeBadException("Unable to delete employee information . Please try after sometime!!");
		}
	}
}
