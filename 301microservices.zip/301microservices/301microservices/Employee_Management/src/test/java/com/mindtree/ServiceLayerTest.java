package com.mindtree;

import static org.junit.Assert.assertNotNull;

import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.mindtree.employee.dao.EmployeeDao;
import com.mindtree.employee.service.impl.EmployeeServiceImpl;
import com.mindtree.entity.Employee;
import com.mindtree.exception.EmployeeBadException;
import com.mindtree.exception.EmployeeNotFoundException;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest(classes = EmployeeManagementApplication.class)
public class ServiceLayerTest {

	@Mock
	private EmployeeDao employeeDao;

	@InjectMocks
	EmployeeServiceImpl employeeServiceImpl;

	Employee employee;
	ResponseEntity<?> responseEntity;
	Optional<Employee> empOpt;
	Optional<?> empOpt1;

	@Before
	public void initialize() {
		employee = new Employee();
		employee.setEmployeeId("M1050799");
		employee.setEmployeeName("Vikash Soni");
		employee.setEmployeesalry("24147");
		employee.setPosition("ENGINEER");
		employee.getEmployeeId();
		employee.getEmployeeName();
		employee.getEmployeesalry();
		employee.getPosition();
		empOpt = Optional.of(employee);
		empOpt1 = Optional.empty();
	}

	@Test
	public void findByEmployeeId() throws EmployeeNotFoundException {

		Mockito.doReturn(empOpt).when(employeeDao).findByEmployeeId(ArgumentMatchers.any(String.class));

		assertNotNull(employeeServiceImpl.findByEmployeeId(employee.getEmployeeId()));
	}

	@Test(expected = EmployeeNotFoundException.class)
	public void findByEmployeeId1() throws EmployeeNotFoundException {
		Mockito.doReturn(empOpt1).when(employeeDao).findByEmployeeId(ArgumentMatchers.any(String.class));
		employeeServiceImpl.findByEmployeeId(employee.getEmployeeId());
	}

	@Test(expected=EmployeeBadException.class)
	public void insertEmployeeData() throws EmployeeNotFoundException, EmployeeBadException {
		Mockito.doReturn(empOpt).when(employeeDao).findByEmployeeId(employee.getEmployeeId());
		assertNotNull(employeeServiceImpl.insertEmployeeData(employee));
	}

	@Test(expected = EmployeeBadException.class)
	public void insertEmployeeData1() throws EmployeeNotFoundException, EmployeeBadException {
		Mockito.doReturn(empOpt1).when(employeeDao).findByEmployeeId(employee.getEmployeeId());
		assertNotNull(employeeServiceImpl.insertEmployeeData(employee));
	}

}
