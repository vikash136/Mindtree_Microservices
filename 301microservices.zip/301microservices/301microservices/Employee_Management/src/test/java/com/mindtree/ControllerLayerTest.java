package com.mindtree;

import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.mindtree.controller.EmployeeController;
import com.mindtree.entity.Employee;
import com.mindtree.exception.EmployeeBadException;
import com.mindtree.exception.EmployeeNotFoundException;
import com.mindtree.service.EmployeeService;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest(classes = EmployeeManagementApplication.class)
public class ControllerLayerTest {

	@Mock
	EmployeeService employeeService;

	@InjectMocks
	EmployeeController employeeController;

	Employee employee;
	ResponseEntity<?> responseEntity;
	
	@Before
	public void initialize() {
		employee = new Employee();
		employee.setEmployeeId("M1050732");
		employee.setEmployeeName("Vikash Soni");
		employee.setEmployeesalry("24147");
		employee.setPosition("ENGINEER");
		employee.getEmployeeId();
		employee.getEmployeeName();
		employee.getEmployeesalry();
		employee.getPosition();
		responseEntity = new ResponseEntity<>(employee, HttpStatus.OK);
	}

	@Test
	public void findByEmployeeId() throws EmployeeNotFoundException {
		Mockito.doReturn(responseEntity).when(employeeService).findByEmployeeId(ArgumentMatchers.any(String.class));
		assertNotNull(employeeController.findByEmployeeId(employee.getEmployeeId()));

	}
	
	@Test
	public void insertEmployeeData() throws EmployeeBadException, EmployeeNotFoundException
	{
		Mockito.doReturn(responseEntity).when(employeeService).insertEmployeeData(ArgumentMatchers.any(Employee.class));
		assertNotNull(employeeController.insertEmployeeData(employee));
	}
	
	@Test
	public void deleteEmployeeRecord() throws EmployeeBadException, EmployeeNotFoundException
	{
		Mockito.doReturn(responseEntity).when(employeeService).deleteEmployeeRecord(ArgumentMatchers.any(String.class));
		assertNotNull(employeeController.deleteEmployeeRecord(employee.getEmployeeId()));
		
	}
}
