package com.mindtree.springhandson.service;

import org.springframework.http.ResponseEntity;
import com.mindtree.springhandson.exception.CartBadException;
import com.mindtree.springhandson.exception.NegativeQunatityException;
import com.mindtree.springhandson.exception.ProductBadException;
import com.mindtree.springhandson.exception.ProductNotFoundException;
import com.mindtree.springhandson.exception.UserBadException;
import com.mindtree.springhandson.exception.UserNotFoundException;
import com.mindtree.springhandson.model.Product;


public interface UserService {

	public ResponseEntity<?> getAllUser() throws UserBadException;


	public ResponseEntity<?> getAllProduct() throws ProductBadException;

	public ResponseEntity<?> getAllCart() throws CartBadException;

	public ResponseEntity<?> findProductByProductId(int productId) throws ProductNotFoundException;

	public ResponseEntity<?> findProductByProductName(String productName) throws ProductNotFoundException;

	public ResponseEntity<?> findProductByProductCategory(String productCategory) throws ProductNotFoundException;

	public ResponseEntity<?> addProducToCart(Product product, int userId) throws ProductNotFoundException, UserNotFoundException;

	public ResponseEntity<String> deletePerticularProductRecord(int userId, int productId) throws UserNotFoundException, ProductNotFoundException;

	public ResponseEntity<String> deleteProductAllByUserId(int userId) throws UserNotFoundException, ProductBadException;

	public ResponseEntity<String> updateProducToCart(int userId, int productId, int productquantity) throws UserNotFoundException, ProductNotFoundException, NegativeQunatityException;

	public ResponseEntity<?> getUserProductPriceData(int userId) throws UserNotFoundException, UserBadException, ProductBadException;

}
