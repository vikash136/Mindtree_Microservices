package com.mindtree.springhandson.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
//@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class Cart implements Comparable<Cart> {

	

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int cartId;
	
	private String cartName;
	
	@JsonIgnore
	@OneToMany(cascade = { CascadeType.MERGE, CascadeType.REFRESH, CascadeType.DETACH,
			CascadeType.REMOVE }, mappedBy = "productCart", orphanRemoval = true)
	private List<Product> cartProducts;
	
	@OneToOne
	private User cartUser;
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + cartId;
		result = prime * result + ((cartName == null) ? 0 : cartName.hashCode());
		result = prime * result + ((cartProducts == null) ? 0 : cartProducts.hashCode());
		result = prime * result + ((cartUser == null) ? 0 : cartUser.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cart other = (Cart) obj;
		if (cartId != other.cartId)
			return false;
		if (cartName == null) {
			if (other.cartName != null)
				return false;
		} else if (!cartName.equals(other.cartName))
			return false;
		if (cartProducts == null) {
			if (other.cartProducts != null)
				return false;
		} else if (!cartProducts.equals(other.cartProducts))
			return false;
		if (cartUser == null) {
			if (other.cartUser != null)
				return false;
		} else if (!cartUser.equals(other.cartUser))
			return false;
		return true;
	}

	public Cart(int cartId, String cartName, List<Product> cartProducts, User cartUser) {
		super();
		this.cartId = cartId;
		this.cartName = cartName;
		this.cartProducts = cartProducts;
		this.cartUser = cartUser;
	}

	public List<Product> getCartProducts() {
		return cartProducts;
	}

	public void setCartProducts(List<Product> cartProducts) {
		this.cartProducts = cartProducts;
	}

	public User getCartUser() {
		return cartUser;
	}

	public void setCartUser(User cartUser) {
		this.cartUser = cartUser;
	}

	public int getCartId() {
		return cartId;
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}

	public String getCartName() {
		return cartName;
	}

	public void setCartName(String cartName) {
		this.cartName = cartName;
	}

	public Cart() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int compareTo(Cart o) {
		// TODO Auto-generated method stub
		return this.cartId - o.cartId;
	}

}
