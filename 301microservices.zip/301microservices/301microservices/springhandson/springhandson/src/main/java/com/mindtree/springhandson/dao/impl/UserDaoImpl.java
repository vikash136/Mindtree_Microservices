package com.mindtree.springhandson.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.springhandson.dao.UserDao;
import com.mindtree.springhandson.exception.CartBadException;
import com.mindtree.springhandson.exception.NegativeQunatityException;
import com.mindtree.springhandson.exception.ProductBadException;
import com.mindtree.springhandson.exception.ProductNotFoundException;
import com.mindtree.springhandson.exception.UserBadException;
import com.mindtree.springhandson.exception.UserNotFoundException;
import com.mindtree.springhandson.model.Cart;
import com.mindtree.springhandson.model.Product;
import com.mindtree.springhandson.model.User;
import com.mindtree.springhandson.model.ViewCart;
import com.mindtree.springhandson.repository.CartRepository;
import com.mindtree.springhandson.repository.ProductRepository;
import com.mindtree.springhandson.repository.UserRepository;

@Service
public class UserDaoImpl implements UserDao {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private CartRepository cartRepository;

	@Override
	public List<User> getAllUser() throws UserBadException {
		try {
			return userRepository.findAll();
		} catch (Exception e) {
			throw new UserBadException("Could not find data please try again later");
		}
	}

	@Override
	public List<Product> getAllProduct() throws ProductBadException {
		try {
			return productRepository.findAll();
		} catch (Exception e) {
			throw new ProductBadException("Could not find data please try again later");
		}
	}

	@Override
	public List<Cart> getAllCart() throws CartBadException {
		try {
			return cartRepository.findAll();
		} catch (Exception e) {
			throw new CartBadException("Could not find data please try again later");
		}
	}

	@Override
	public Optional<Product> findProductByProductId(int productId) throws ProductNotFoundException {
		try {
			return productRepository.findById(productId);
		} catch (Exception e) {
			throw new ProductNotFoundException(
					"MIght be you're entered duplicate data, please try again with new product info.");
		}
	}

	@Override
	public List<Product> findProductByProductName(String productName) throws ProductNotFoundException {
		try {
			return productRepository.findByproductName(productName);
		} catch (Exception e) {
			throw new ProductNotFoundException(
					"MIght be you're entered duplicate data, please try again with new product info.");
		}
	}

	@Override
	public List<Product> findProductByProductCategory(String productCategory) throws ProductNotFoundException {
		try {
			return productRepository.findByproductCategory(productCategory);
		} catch (Exception e) {
			throw new ProductNotFoundException(
					"MIght be you're entered duplicate data, please try again with new product info.");
		}
	}

	@Override
	public Product addProducToCart(Product product, int userId) throws UserNotFoundException {
		User user = userRepository.findById(userId)
				.orElseThrow(() -> new UserNotFoundException("sorry user not found"));
		Cart cart = user.getUserCart();
		int count = 0;
		for (int i = 0; i < cart.getCartProducts().size(); i++) {
			if (product.getProductName().equalsIgnoreCase(cart.getCartProducts().get(i).getProductName())) {
				count = 1;
				cart.getCartProducts().get(i)
						.setProductquantity(cart.getCartProducts().get(i).getProductquantity() + 1);
				product.setProductquantity(cart.getCartProducts().get(i).getProductquantity());
			}
		}
		if (count == 0) {
			product.setProductquantity(1);
			cart.getCartProducts().add(product);
		}
		product.setProductCart(cart);
		cartRepository.saveAndFlush(cart);
		return product;
	}

	@Override
	public String deletePerticularProductRecord(int userId, int productId)
			throws UserNotFoundException, ProductNotFoundException {
		User user = userRepository.findById(userId)
				.orElseThrow(() -> new UserNotFoundException("sorry user not found"));
		Cart cart = user.getUserCart();

		int count = 0;
		for (Product product1 : cart.getCartProducts()) {
			if (product1.getProductId() == productId) {
				count = 1;
				productRepository.delete(product1);
				break;

			}
		}
		if (count == 0) {
			throw new ProductNotFoundException("sorry product not found ");
		}
		return "Deleted successfully";
	}

	@Override
	public String deleteProductAllByUserId(int userId) throws UserNotFoundException, ProductBadException {
		User user = userRepository.findById(userId)
				.orElseThrow(() -> new UserNotFoundException("sorry user not found"));
		Cart cart = user.getUserCart();
		if(cart.getCartProducts().size()==0) {
			throw new ProductBadException("This user does not have any product");
		}
		for (Product product1 : cart.getCartProducts()) {

			productRepository.delete(product1);

		}
		return "Deleted successfully";

	}

	@Override
	public String updateProducToCart(int userId, int productId, int productquantity)
			throws UserNotFoundException, ProductNotFoundException, NegativeQunatityException {
		if (productquantity < 0) {
			throw new NegativeQunatityException("Quantity can not be negative");
		}
		User user = userRepository.findById(userId)
				.orElseThrow(() -> new UserNotFoundException("sorry user not found"));
		Cart cart = user.getUserCart();
		int count = 0;
		for (Product product1 : cart.getCartProducts()) {
			if (product1.getProductId() == productId) {
				count = 1;
				break;
			}
		}

		if (count == 0) {
			throw new ProductNotFoundException("sorry product not found");
		}
		for (int i = 0; i < cart.getCartProducts().size(); i++) {
			if (cart.getCartProducts().get(i).getProductId() == productId) {
				if (productquantity == 0) {
					cart.getCartProducts().remove(i);
					productRepository.deleteById(productId);
				} else {
					productRepository.updateQuantity(cart.getCartProducts().get(i).getProductId(), productquantity);
				}
			}
		}
		cartRepository.saveAndFlush(cart);
		return "Updated Successfully !!!";
	}

	@Override
	public ViewCart getUserProductPriceData(int userId) throws UserNotFoundException, ProductBadException {
		User user = userRepository.findById(userId)
				.orElseThrow(() -> new UserNotFoundException("sorry user not found"));
		ViewCart viewCart = new ViewCart();
		Cart cart = user.getUserCart();
		if(cart.getCartProducts().size()==0) {
			throw new ProductBadException("This user does not have any product");
		}
		viewCart.setTotalPrice(cart.getCartProducts().stream().map(p -> p.getProductPrice() * p.getProductquantity())
				.reduce(0.0, (element1, element2) -> element1 + element2));
		viewCart.setProduct(cart.getCartProducts());
		return viewCart;
	}

}
