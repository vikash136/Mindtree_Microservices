package com.mindtree.springhandson.service.impl;

import java.util.List;
import java.util.Optional;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.mindtree.springhandson.dao.UserDao;
import com.mindtree.springhandson.exception.CartBadException;
import com.mindtree.springhandson.exception.NegativeQunatityException;
import com.mindtree.springhandson.exception.ProductBadException;
import com.mindtree.springhandson.exception.ProductNotFoundException;
import com.mindtree.springhandson.exception.UserBadException;
import com.mindtree.springhandson.exception.UserNotFoundException;
import com.mindtree.springhandson.model.Cart;
import com.mindtree.springhandson.model.Product;
import com.mindtree.springhandson.model.User;
import com.mindtree.springhandson.model.ViewCart;
import com.mindtree.springhandson.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao userDao;

	@Override
	public ResponseEntity<?> getAllUser() throws UserBadException {

		List<User> allUsers = userDao.getAllUser();

		if (!CollectionUtils.isEmpty(allUsers)) {
			return new ResponseEntity<>(allUsers, HttpStatus.OK);
		} else {
			throw new UserBadException("Could not find data please try again later");
		}
	}

	@Override
	public ResponseEntity<?> getAllProduct() throws ProductBadException {
		List<Product> allProducts = userDao.getAllProduct();
		if (!CollectionUtils.isEmpty(allProducts)) {
			return new ResponseEntity<>(allProducts, HttpStatus.OK);
		} else {
			throw new ProductBadException("Could not find data please try again later");
		}
	}

	@Override
	public ResponseEntity<?> getAllCart() throws CartBadException {
		List<Cart> allcarts = userDao.getAllCart();
		if (!CollectionUtils.isEmpty(allcarts)) {
			return new ResponseEntity<>(allcarts, HttpStatus.OK);
		} else {
			throw new CartBadException("Could not find data please try again later");
		}
	}



	@Override
	public ResponseEntity<?> findProductByProductId(int productId) throws ProductNotFoundException {
		Optional<Product> productObjectId = userDao.findProductByProductId(productId);
		if (productObjectId.isPresent()) {
			return new ResponseEntity<>(productObjectId.get(), HttpStatus.OK);
		} else {
			throw new ProductNotFoundException(
					"MIght be you're entered duplicate data, please try again with new product info.");
		}
	}

	@Override
	public ResponseEntity<?> findProductByProductName(String productName) throws ProductNotFoundException {
		List<Product> productObjectName = userDao.findProductByProductName(productName);
		if (productObjectName.size() > 0) {
			return new ResponseEntity<>(productObjectName, HttpStatus.OK);
		} else {
			throw new ProductNotFoundException(
					"MIght be you're entered duplicate data, please try again with new product info.");
		}
	}

	@Override
	public ResponseEntity<?> findProductByProductCategory(String productCategory) throws ProductNotFoundException {
		List<Product> productObjectCategory = userDao.findProductByProductCategory(productCategory);
		if (productObjectCategory.size() > 0) {
			return new ResponseEntity<>(productObjectCategory, HttpStatus.OK);
		} else {
			throw new ProductNotFoundException(
					"MIght be you're entered duplicate data, please try again with new product info.");
		}
	}

	@Override
	public ResponseEntity<?> addProducToCart(Product product, int userId)
			throws ProductNotFoundException, UserNotFoundException {
		Product product2 = userDao.addProducToCart(product, userId);
		if (product2 != null) {
			return new ResponseEntity<>(product, HttpStatus.OK);
		} else {
			throw new ProductNotFoundException(
					"MIght be you're entered duplicate data, please try again with new userid and product info.");
		}
	}

	@Override
	public ResponseEntity<String> deletePerticularProductRecord(int userId, int productId)
			throws UserNotFoundException, ProductNotFoundException {
		return new ResponseEntity<String>(userDao.deletePerticularProductRecord(userId, productId), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<String> deleteProductAllByUserId(int userId) throws UserNotFoundException, ProductBadException {
		return new ResponseEntity<String>(userDao.deleteProductAllByUserId(userId), HttpStatus.OK);

	}

	@Override
	public ResponseEntity<String> updateProducToCart(int userId, int productId, int productquantity)
			throws UserNotFoundException, ProductNotFoundException, NegativeQunatityException {
		return new ResponseEntity<String>(userDao.updateProducToCart(userId, productId, productquantity),
				HttpStatus.OK);
	}

	@Override
	public ResponseEntity<?> getUserProductPriceData(int userId) throws UserNotFoundException, UserBadException, ProductBadException {
		ViewCart viewCart = userDao.getUserProductPriceData(userId);

		if (viewCart != null) {
			return new ResponseEntity<>(viewCart, HttpStatus.OK);
		} else {
			throw new UserBadException("Could not find data please try again later");
		}
	}

}
