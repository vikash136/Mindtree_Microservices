package com.mindtree.springhandson.model;

import java.util.List;

public class ViewCart {

	private List<Product> product;

	private double totalPrice;

	public ViewCart() {
		super();
	}

	public ViewCart(List<Product> product, double totalPrice) {
		this.product = product;
		this.totalPrice = totalPrice;
	}

	public List<Product> getProduct() {
		return product;
	}

	public void setProduct(List<Product> product) {
		this.product = product;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

}