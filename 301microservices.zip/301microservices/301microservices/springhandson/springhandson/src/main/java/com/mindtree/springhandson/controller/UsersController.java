package com.mindtree.springhandson.controller;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mindtree.springhandson.exception.CartBadException;
import com.mindtree.springhandson.exception.CartNotFoundException;
import com.mindtree.springhandson.exception.NegativeQunatityException;
import com.mindtree.springhandson.exception.ProductBadException;
import com.mindtree.springhandson.exception.ProductNotFoundException;
import com.mindtree.springhandson.exception.UserBadException;
import com.mindtree.springhandson.exception.UserNotFoundException;
import com.mindtree.springhandson.model.Product;
import com.mindtree.springhandson.service.UserService;


@Controller
@RequestMapping("/welcome")
public class UsersController {

	
	@Autowired
	private UserService userService;

	private Logger LOG = Logger.getLogger(UsersController.class);

	@RequestMapping(value = "/userAll", method = RequestMethod.GET)
	public ResponseEntity<?> getAllUser() throws UserNotFoundException, UserBadException {
		LOG.debug("====Get all User data ====");
		return userService.getAllUser();
	}
	
	@RequestMapping(value = "/productAll", method = RequestMethod.GET)
	public ResponseEntity<?> getAllProduct() throws ProductNotFoundException, ProductBadException {
		LOG.debug("====Get all product data ====");
		return userService.getAllProduct();
	}
	@RequestMapping(value = "/cartAll", method = RequestMethod.GET)
	public ResponseEntity<?> getAllCart() throws CartNotFoundException, CartBadException {
		LOG.debug("====Get all cart data ====");
		return userService.getAllCart();
	}
	

	
	@RequestMapping(value = "product/productId/{productId}", method = RequestMethod.GET)
	public ResponseEntity<?> findProductByProductId(@PathVariable(value = "productId") int productId) throws ProductNotFoundException, ProductBadException {
		LOG.debug("====Get all Product data based on product Id ====");
		return userService.findProductByProductId(productId);
	}
	
	@RequestMapping(value = "product/productName/{productName}", method = RequestMethod.GET)
	public ResponseEntity<?> findProductByProductName(@PathVariable(value = "productName") String productName) throws ProductNotFoundException, ProductBadException {
		LOG.debug("====Get all Product data based on product Name ====");
		return userService.findProductByProductName(productName);
	}
	
	@RequestMapping(value = "product/productCategory/{productCategory}", method = RequestMethod.GET)
	public ResponseEntity<?> findProductByProductCategory(@PathVariable(value = "productCategory") String productCategory) throws ProductNotFoundException, ProductBadException {
		LOG.debug("====Get all Product data based on  product Category ====");
		return userService.findProductByProductCategory(productCategory);
	}
	
	
	@RequestMapping(value = "product/cart/userId/{userId}", method = RequestMethod.POST)
	public ResponseEntity<?> addProducToCart(@RequestBody Product product, @PathVariable(value="userId")int userId ) throws ProductNotFoundException, ProductBadException, UserNotFoundException {
		LOG.debug("====Add  Product data and increment bases on user ID  ====");
		return userService.addProducToCart(product,userId);
	}
	
	@RequestMapping(value = "/product/userId/productId/{userId}/{productId}", method = RequestMethod.DELETE)
	public ResponseEntity<String> deletePerticularProductRecord(@PathVariable(value = "userId") int userId,@PathVariable(value = "productId") int productId )
			throws ProductNotFoundException, ProductBadException, UserNotFoundException {
		LOG.debug("====Delete Product data  from userID and productId ====");
		return userService.deletePerticularProductRecord(userId,productId);
	}
	
	@RequestMapping(value = "/productDeleteAll/userId/{userId}", method = RequestMethod.DELETE)
	public ResponseEntity<String> deleteProductAllByUserId(@PathVariable(value = "userId") int userId)
			throws UserNotFoundException, ProductBadException {
		LOG.debug("====Delete Product all data  from userId ID ====");
		return userService.deleteProductAllByUserId(userId);
	}
	
	@RequestMapping(value = "/product/userId/productId/productquantity/{userId}/{productId}/{productquantity}", method = RequestMethod.PUT)
	public ResponseEntity<String> updateProducToCart(@PathVariable(value="userId")int userId,@PathVariable(value="productId")int productId,@PathVariable(value="productquantity")int productquantity ) throws ProductNotFoundException, ProductBadException, UserNotFoundException, NegativeQunatityException {
		LOG.debug("====Update Product data bases on user ID  ====");
		return userService.updateProducToCart(userId,productId,productquantity);
	}
	
	@RequestMapping(value = "/userPriceData/userId/{userId}", method = RequestMethod.GET)
	public ResponseEntity<?> getUserProductPriceData(@PathVariable(value="userId")int userId) throws UserNotFoundException, UserBadException, ProductBadException {
		LOG.debug("====Get total price bases on  userId ====");
		return userService.getUserProductPriceData(userId);
	}
}
