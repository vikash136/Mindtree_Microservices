package com.mindtree.springhandson.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.mindtree.springhandson.model.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product, Integer> {

	public List<Product> findByproductName(String productName);

	public List<Product> findByproductCategory(String productCategory);

	@Modifying
	@Transactional
	@Query(nativeQuery = true, value = "UPDATE product p SET p.productquantity=:productquantity where p.product_id= :productId")
	public int updateQuantity(int productId, int productquantity);


}
