package com.mindtree.springhandson.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;



@ControllerAdvice
public class ExceptionHandler extends ResponseEntityExceptionHandler {

	@org.springframework.web.bind.annotation.ExceptionHandler(UserNotFoundException.class)
	public final ResponseEntity<ExceptionResponse> handleUserNotFoundException(ExceptionResponse ex) {
		return new ResponseEntity(new ExceptionResponse(ex.getMessage()), HttpStatus.NOT_FOUND);
	}

	@org.springframework.web.bind.annotation.ExceptionHandler(UserBadException.class)
	public final ResponseEntity<ExceptionResponse> handleUserBadRequestException(ExceptionResponse ex) {
		return new ResponseEntity(new ExceptionResponse(ex.getMessage()), HttpStatus.BAD_REQUEST);
	}
	
	@org.springframework.web.bind.annotation.ExceptionHandler(ProductNotFoundException.class)
	public final ResponseEntity<ExceptionResponse> handleProductNotFoundException(ExceptionResponse ex) {
		return new ResponseEntity(new ExceptionResponse(ex.getMessage()), HttpStatus.NOT_FOUND);
	}

	@org.springframework.web.bind.annotation.ExceptionHandler(ProductBadException.class)
	public final ResponseEntity<ExceptionResponse> handleProductBadRequestException(ExceptionResponse ex) {
		return new ResponseEntity(new ExceptionResponse(ex.getMessage()), HttpStatus.BAD_REQUEST);
	}
	
	@org.springframework.web.bind.annotation.ExceptionHandler(CartNotFoundException.class)
	public final ResponseEntity<ExceptionResponse> handleCartNotFoundException(ExceptionResponse ex) {
		return new ResponseEntity(new ExceptionResponse(ex.getMessage()), HttpStatus.NOT_FOUND);
	}

	@org.springframework.web.bind.annotation.ExceptionHandler(CartBadException.class)
	public final ResponseEntity<ExceptionResponse> handleCartBadRequestException(ExceptionResponse ex) {
		return new ResponseEntity(new ExceptionResponse(ex.getMessage()), HttpStatus.BAD_REQUEST);
	}
	
	@org.springframework.web.bind.annotation.ExceptionHandler(NegativeQunatityException.class)
	public final ResponseEntity<ExceptionResponse> handleNegativeQunatityException(ExceptionResponse ex) {
		return new ResponseEntity(new ExceptionResponse(ex.getMessage()), HttpStatus.NOT_FOUND);
	}
}
