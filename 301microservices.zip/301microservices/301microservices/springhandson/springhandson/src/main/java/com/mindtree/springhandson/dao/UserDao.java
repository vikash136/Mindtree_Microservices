package com.mindtree.springhandson.dao;

import java.util.List;
import java.util.Optional;

import com.mindtree.springhandson.exception.CartBadException;
import com.mindtree.springhandson.exception.NegativeQunatityException;
import com.mindtree.springhandson.exception.ProductBadException;
import com.mindtree.springhandson.exception.ProductNotFoundException;
import com.mindtree.springhandson.exception.UserBadException;
import com.mindtree.springhandson.exception.UserNotFoundException;
import com.mindtree.springhandson.model.Cart;
import com.mindtree.springhandson.model.Product;
import com.mindtree.springhandson.model.User;
import com.mindtree.springhandson.model.ViewCart;

public interface UserDao {

	public List<User> getAllUser() throws UserBadException;



	public List<Product> getAllProduct() throws ProductBadException;

	public List<Cart> getAllCart() throws CartBadException;

	public Optional<Product> findProductByProductId(int productId) throws ProductNotFoundException;

	public List<Product> findProductByProductName(String productName) throws ProductNotFoundException;

	public List<Product> findProductByProductCategory(String productCategory) throws ProductNotFoundException;

	public Product addProducToCart(Product product, int userId) throws UserNotFoundException;

	public String deletePerticularProductRecord(int userId, int productId) throws UserNotFoundException, ProductNotFoundException;

	public String deleteProductAllByUserId(int userId) throws UserNotFoundException, ProductBadException;

	public String updateProducToCart(int userId, int productId, int productquantity) throws UserNotFoundException, ProductNotFoundException, NegativeQunatityException;

	public ViewCart getUserProductPriceData(int userId) throws UserNotFoundException, ProductBadException;

	

}
