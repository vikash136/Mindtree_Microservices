package com.mindtree.springhandson.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
//@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class User implements Comparable<User>  {

	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int userId;
	
	private String userName;
	
	@JsonIgnore
	@OneToOne(cascade = CascadeType.ALL, mappedBy = "cartUser")
	private Cart userCart;

	public User() {
		
	}

	public User(int userId, String userName, Cart userCart) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.userCart = userCart;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Cart getUserCart() {
		return userCart;
	}

	public void setUserCart(Cart userCart) {
		this.userCart = userCart;
	}

	@Override
	public int compareTo(User o) {
		// TODO Auto-generated method stub
		return this.userId - o.userId;
	}

}

