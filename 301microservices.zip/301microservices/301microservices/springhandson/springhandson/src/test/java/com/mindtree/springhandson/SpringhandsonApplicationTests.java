package com.mindtree.springhandson;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringhandsonApplicationTests {

	@Test
	void contextLoads() {
	}

}
