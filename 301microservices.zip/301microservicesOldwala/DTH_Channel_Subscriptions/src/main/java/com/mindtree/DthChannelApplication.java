package com.mindtree;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DthChannelApplication {

	public static void main(String[] args) 
	{
		SpringApplication.run(DthChannelApplication.class, args);
	}

}
