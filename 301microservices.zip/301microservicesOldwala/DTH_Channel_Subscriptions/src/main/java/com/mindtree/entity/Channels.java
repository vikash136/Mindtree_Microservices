package com.mindtree.entity;

import javax.persistence.Entity;

import io.swagger.annotations.ApiModelProperty;

@Entity
public class Channels {
	
	@ApiModelProperty(notes = "CHANNEL_ID")
	 private String channelID;
	
	@ApiModelProperty(notes = "CHANNEL_NAME")
	 private String channelName;
	
	@ApiModelProperty(notes = "COST_PER_MONTH")
	 private String costPerMonth;
	 
	public String getChannelID() {
		return channelID;
	}
	public void setChannelID(String channelID) {
		this.channelID = channelID;
	}
	public String getChannelName() {
		return channelName;
	}
	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}
	public String getCostPerMonth() {
		return costPerMonth;
	}
	public void setCostPerMonth(String costPerMonth) {
		this.costPerMonth = costPerMonth;
	}
	 
	 
	

}
