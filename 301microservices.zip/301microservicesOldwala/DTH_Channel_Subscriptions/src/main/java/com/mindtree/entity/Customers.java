package com.mindtree.entity;

import javax.persistence.Entity;
import io.swagger.annotations.ApiModelProperty;

@Entity
public class Customers {

	@ApiModelProperty(notes = "SUBSCRIBER_ID")
	private String subscriberID;

	@ApiModelProperty(notes = "REGISTERED_MOBILE")
	private String registerdMobile;

	@ApiModelProperty(notes = "FIRST_NAME")
	private String fristName;

	@ApiModelProperty(notes = " LAST_NAME")
	private String lastName;

	public String getSubscriberID() {
		return subscriberID;
	}

	public void setSubscriberID(String subscriberID) {
		this.subscriberID = subscriberID;
	}

	public String getRegisterdMobile() {
		return registerdMobile;
	}

	public void setRegisterdMobile(String registerdMobile) {
		this.registerdMobile = registerdMobile;
	}

	public String getFristName() {
		return fristName;
	}

	public void setFristName(String fristName) {
		this.fristName = fristName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

}
