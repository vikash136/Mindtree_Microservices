  package com.mindtree.entity;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"10",
"Mat",
"Inns",
"Balls",
"Runs",
"Wkts",
"BBI",
"BBM",
"Ave",
"Econ",
"SR",
"4w",
"5w"
})
public class T20Is {

@JsonProperty("10")
private String _10;
@JsonProperty("Mat")
private String mat;
@JsonProperty("Inns")
private String inns;
@JsonProperty("Balls")
private String balls;
@JsonProperty("Runs")
private String runs;
@JsonProperty("Wkts")
private String wkts;
@JsonProperty("BBI")
private String bBI;
@JsonProperty("BBM")
private String bBM;
@JsonProperty("Ave")
private String ave;
@JsonProperty("Econ")
private String econ;
@JsonProperty("SR")
private String sR;
@JsonProperty("4w")
private String _4w;
@JsonProperty("5w")
private String _5w;
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

/**
* No args constructor for use in serialization
*
*/
public T20Is() {
}

/**
*
* @param _5w
* @param mat
* @param _4w
* @param wkts
* @param balls
* @param bBI
* @param bBM
* @param ave
* @param econ
* @param inns
* @param runs
* @param _10
* @param sR
*/
public T20Is(String _10, String mat, String inns, String balls, String runs, String wkts, String bBI, String bBM, String ave, String econ, String sR, String _4w, String _5w) {
super();
this._10 = _10;
this.mat = mat;
this.inns = inns;
this.balls = balls;
this.runs = runs;
this.wkts = wkts;
this.bBI = bBI;
this.bBM = bBM;
this.ave = ave;
this.econ = econ;
this.sR = sR;
this._4w = _4w;
this._5w = _5w;
}

@JsonProperty("10")
public String get10() {
return _10;
}

@JsonProperty("10")
public void set10(String _10) {
this._10 = _10;
}

@JsonProperty("Mat")
public String getMat() {
return mat;
}

@JsonProperty("Mat")
public void setMat(String mat) {
this.mat = mat;
}

@JsonProperty("Inns")
public String getInns() {
return inns;
}

@JsonProperty("Inns")
public void setInns(String inns) {
this.inns = inns;
}

@JsonProperty("Balls")
public String getBalls() {
return balls;
}

@JsonProperty("Balls")
public void setBalls(String balls) {
this.balls = balls;
}

@JsonProperty("Runs")
public String getRuns() {
return runs;
}

@JsonProperty("Runs")
public void setRuns(String runs) {
this.runs = runs;
}

@JsonProperty("Wkts")
public String getWkts() {
return wkts;
}

@JsonProperty("Wkts")
public void setWkts(String wkts) {
this.wkts = wkts;
}

@JsonProperty("BBI")
public String getBBI() {
return bBI;
}

@JsonProperty("BBI")
public void setBBI(String bBI) {
this.bBI = bBI;
}

@JsonProperty("BBM")
public String getBBM() {
return bBM;
}

@JsonProperty("BBM")
public void setBBM(String bBM) {
this.bBM = bBM;
}

@JsonProperty("Ave")
public String getAve() {
return ave;
}

@JsonProperty("Ave")
public void setAve(String ave) {
this.ave = ave;
}

@JsonProperty("Econ")
public String getEcon() {
return econ;
}

@JsonProperty("Econ")
public void setEcon(String econ) {
this.econ = econ;
}

@JsonProperty("SR")
public String getSR() {
return sR;
}

@JsonProperty("SR")
public void setSR(String sR) {
this.sR = sR;
}

@JsonProperty("4w")
public String get4w() {
return _4w;
}

@JsonProperty("4w")
public void set4w(String _4w) {
this._4w = _4w;
}

@JsonProperty("5w")
public String get5w() {
return _5w;
}

@JsonProperty("5w")
public void set5w(String _5w) {
this._5w = _5w;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}

