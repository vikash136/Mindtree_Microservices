package com.mindtree.datasource;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.mindtree.entity.Player;
import com.mindtree.entity.PlayerStats;

@Component
public class CricketPlayerDataSource {

	@Value("${api.key}")
	private String apikey;
	private Logger LOG = Logger.getLogger(CricketPlayerDataSource.class);
	private String url = "https://cricapi.com/api/playerStats";

	@Autowired
	private RestTemplate restTemplate;

	public Player getCricketPlayerInfo(int playerId) {

		PlayerStats palyerSummary = restTemplate.getForObject(url+"?apikey="+apikey+"&pid="+playerId,PlayerStats.class);
		LOG.debug("=== CricketPlayerDataSource====");
		System.out.println("palyerSummary"+ palyerSummary.toString());
		int numOfMatchesPlayed = Integer.parseInt((palyerSummary.getData().getBowling().getListA().getMat()))
				+ Integer.parseInt((palyerSummary.getData().getBowling().getFirstClass().getMat()))
				+ Integer.parseInt((palyerSummary.getData().getBowling().getODIs().getMat()))
				+ Integer.parseInt((palyerSummary.getData().getBowling().getT20Is().getMat()))
				+ Integer.parseInt((palyerSummary.getData().getBowling().getTests().getMat()))
				+ Integer.parseInt((palyerSummary.getData().getBatting().getListA().getMat()))
				+ Integer.parseInt((palyerSummary.getData().getBatting().getFirstClass().getMat()))
				+ Integer.parseInt((palyerSummary.getData().getBatting().getODIs().getMat()))
				+ Integer.parseInt((palyerSummary.getData().getBatting().getT20Is().getMat()))
				+ Integer.parseInt((palyerSummary.getData().getBatting().getTests().getMat()));

		int Wickets = Integer.parseInt((palyerSummary.getData().getBowling().getListA().getWkts()))
				+ Integer.parseInt((palyerSummary.getData().getBowling().getFirstClass().getWkts()))
				+ Integer.parseInt((palyerSummary.getData().getBowling().getODIs().getWkts()))
				+ Integer.parseInt((palyerSummary.getData().getBowling().getT20Is().getWkts()))
				+ Integer.parseInt((palyerSummary.getData().getBowling().getTests().getWkts()));

		int fifties = Integer.parseInt((palyerSummary.getData().getBatting().getListA().get50()))
				+ Integer.parseInt((palyerSummary.getData().getBatting().getFirstClass().get50()))
				+ Integer.parseInt((palyerSummary.getData().getBatting().getODIs().get50()))
				+ Integer.parseInt((palyerSummary.getData().getBatting().getT20Is().get50()))
				+ Integer.parseInt((palyerSummary.getData().getBatting().getTests().get50()));

		int hundreds = Integer.parseInt((palyerSummary.getData().getBatting().getListA().get100()))
				+ Integer.parseInt((palyerSummary.getData().getBatting().getFirstClass().get100()))
				+ Integer.parseInt((palyerSummary.getData().getBatting().getODIs().get100()))
				+ Integer.parseInt((palyerSummary.getData().getBatting().getT20Is().get100()))
				+ Integer.parseInt((palyerSummary.getData().getBatting().getTests().get100()));

		Player player = new Player();
		player.setPlayerId(playerId);
		player.setName(palyerSummary.getFullName());
		player.setCategory(palyerSummary.getPlayingRole());
		player.setNumOfMatchesPlayed(numOfMatchesPlayed);
		player.setFifties(fifties);
		player.setHundreds(hundreds);
		player.setWickets(Wickets);
		return player;

	}

}
