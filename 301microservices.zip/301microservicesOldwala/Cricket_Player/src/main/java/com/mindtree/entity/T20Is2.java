package com.mindtree.entity;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"50",
"100",
"Mat",
"Inns",
"NO",
"Runs",
"HS",
"Ave",
"BF",
"SR",
"4s",
"6s",
"Ct",
"St"
})
public class T20Is2 {

@JsonProperty("50")
private String _50;
@JsonProperty("100")
private String _100;
@JsonProperty("Mat")
private String mat;
@JsonProperty("Inns")
private String inns;
@JsonProperty("NO")
private String nO;
@JsonProperty("Runs")
private String runs;
@JsonProperty("HS")
private String hS;
@JsonProperty("Ave")
private String ave;
@JsonProperty("BF")
private String bF;
@JsonProperty("SR")
private String sR;
@JsonProperty("4s")
private String _4s;
@JsonProperty("6s")
private String _6s;
@JsonProperty("Ct")
private String ct;
@JsonProperty("St")
private String st;
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

/**
* No args constructor for use in serialization
*
*/
public T20Is2() {
}

/**
*
* @param mat
* @param nO
* @param st
* @param bF
* @param hS
* @param ave
* @param ct
* @param _100
* @param _50
* @param inns
* @param runs
* @param _6s
* @param sR
* @param _4s
*/
public T20Is2(String _50, String _100, String mat, String inns, String nO, String runs, String hS, String ave, String bF, String sR, String _4s, String _6s, String ct, String st) {
super();
this._50 = _50;
this._100 = _100;
this.mat = mat;
this.inns = inns;
this.nO = nO;
this.runs = runs;
this.hS = hS;
this.ave = ave;
this.bF = bF;
this.sR = sR;
this._4s = _4s;
this._6s = _6s;
this.ct = ct;
this.st = st;
}

@JsonProperty("50")
public String get50() {
return _50;
}

@JsonProperty("50")
public void set50(String _50) {
this._50 = _50;
}

@JsonProperty("100")
public String get100() {
return _100;
}

@JsonProperty("100")
public void set100(String _100) {
this._100 = _100;
}

@JsonProperty("Mat")
public String getMat() {
return mat;
}

@JsonProperty("Mat")
public void setMat(String mat) {
this.mat = mat;
}

@JsonProperty("Inns")
public String getInns() {
return inns;
}

@JsonProperty("Inns")
public void setInns(String inns) {
this.inns = inns;
}

@JsonProperty("NO")
public String getNO() {
return nO;
}

@JsonProperty("NO")
public void setNO(String nO) {
this.nO = nO;
}

@JsonProperty("Runs")
public String getRuns() {
return runs;
}

@JsonProperty("Runs")
public void setRuns(String runs) {
this.runs = runs;
}

@JsonProperty("HS")
public String getHS() {
return hS;
}

@JsonProperty("HS")
public void setHS(String hS) {
this.hS = hS;
}

@JsonProperty("Ave")
public String getAve() {
return ave;
}

@JsonProperty("Ave")
public void setAve(String ave) {
this.ave = ave;
}

@JsonProperty("BF")
public String getBF() {
return bF;
}

@JsonProperty("BF")
public void setBF(String bF) {
this.bF = bF;
}

@JsonProperty("SR")
public String getSR() {
return sR;
}

@JsonProperty("SR")
public void setSR(String sR) {
this.sR = sR;
}

@JsonProperty("4s")
public String get4s() {
return _4s;
}

@JsonProperty("4s")
public void set4s(String _4s) {
this._4s = _4s;
}

@JsonProperty("6s")
public String get6s() {
return _6s;
}

@JsonProperty("6s")
public void set6s(String _6s) {
this._6s = _6s;
}

@JsonProperty("Ct")
public String getCt() {
return ct;
}

@JsonProperty("Ct")
public void setCt(String ct) {
this.ct = ct;
}

@JsonProperty("St")
public String getSt() {
return st;
}

@JsonProperty("St")
public void setSt(String st) {
this.st = st;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}

