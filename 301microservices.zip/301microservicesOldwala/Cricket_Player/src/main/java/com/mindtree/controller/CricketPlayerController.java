package com.mindtree.controller;

import java.util.List;
import java.util.Optional;
import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.mindtree.entity.Player;
import com.mindtree.service.CricketPlayerService;

@RestController
@RequestMapping("/api")
public class CricketPlayerController {

	@Autowired
	private CricketPlayerService cricketPlayerService;
	private Logger LOG = Logger.getLogger(CricketPlayerController.class);

	@RequestMapping(value ="/getAllPlayerDetails", method = RequestMethod.GET)
	public List<Player> getAllPlayerDetails() {
		return cricketPlayerService.getAllPlayerDetails();
	}

	@RequestMapping(value ="/playerId/{playerId}", method = RequestMethod.GET)
	public Optional<Player> getPlayerById(@PathVariable int playerId) {
		return cricketPlayerService.getPlayerById(playerId);
	}

	@RequestMapping(value ="/save/{playerId}", method = RequestMethod.POST)
	public Player saveplayer(@PathVariable (value="playerId") int playerId) {
		LOG.debug("=== insertion start====");
		System.out.println(saveplayer(playerId));
		return cricketPlayerService.saveplayer(playerId);
	}
	@RequestMapping(value ="/playerIdDelete/{playerId}", method = RequestMethod.DELETE)
	public String deletePlayerById(@PathVariable (value="playerId") int playerId) {
		return cricketPlayerService.deletePlayerById(playerId);
	}
}