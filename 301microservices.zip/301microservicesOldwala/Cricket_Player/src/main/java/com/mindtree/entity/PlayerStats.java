package com.mindtree.entity;

public class PlayerStats {

	private int pid;
	private String FullName;
	private String playingRole;
	Data data;

	public PlayerStats() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PlayerStats(int pid, String fullName, String playingRole, Data data) {
		this.pid = pid;
		FullName = fullName;
		this.playingRole = playingRole;
		this.data = data;
	}

	@Override
	public String toString() {
		return "PlayerStats [pid=" + pid + ", FullName=" + FullName + ", playingRole=" + playingRole + ", data=" + data
				+ "]";
	}

	public int getpId() {
		return pid;
	}

	public void setpId(int pId) {
		this.pid = pId;
	}

	public String getFullName() {
		return FullName;
	}

	public void setFullName(String fullName) {
		FullName = fullName;
	}

	public String getPlayingRole() {
		return playingRole;
	}

	public void setPlayingRole(String playingRole) {
		this.playingRole = playingRole;
	}

	public Data getData() {
		return data;
	}

	public void setData(Data data) {
		this.data = data;
	}

}