
package com.mindtree.entity;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "listA", "firstClass", "T20Is", "ODIs", "tests" })
public class Batting {

	@JsonProperty("listA")
	private ListA2 listA;
	@JsonProperty("firstClass")
	private FirstClass2 firstClass;
	@JsonProperty("T20Is")
	private T20Is2 t20Is;
	@JsonProperty("ODIs")
	private ODIs2 oDIs;
	@JsonProperty("tests")
	private Tests2 tests;

	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	public Batting() {
	}

	public Batting(ListA2 listA, FirstClass2 firstClass, T20Is2 t20Is, ODIs2 oDIs, Tests2 test,
			Map<String, Object> additionalProperties) {
		this.listA = listA;
		this.firstClass = firstClass;
		this.t20Is = t20Is;
		this.oDIs = oDIs;
		this.tests = test;
		this.additionalProperties = additionalProperties;
	}

	@JsonProperty("tests")
	public Tests2 getTests() {
		return tests;
	}

	@JsonProperty("tests")
	public void setTests(Tests2 tests) {
		this.tests = tests;
	}

	@JsonProperty("ODIs")
	public ODIs2 getODIs() {
		return oDIs;
	}

	@JsonProperty("ODIs")
	public void setODIs(ODIs2 oDIs) {
		this.oDIs = oDIs;
	}

	@JsonProperty("T20Is")
	public T20Is2 getT20Is() {
		return t20Is;
	}

	@JsonProperty("T20Is")
	public void setT20Is(T20Is2 t20Is) {
		this.t20Is = t20Is;
	}

	@JsonProperty("firstClass")
	public FirstClass2 getFirstClass() {
		return firstClass;
	}

	@JsonProperty("firstClass")
	public void setFirstClass(FirstClass2 firstClass) {
		this.firstClass = firstClass;
	}

	@JsonProperty("listA")
	public ListA2 getListA() {
		return listA;
	}

	@JsonProperty("listA")
	public void setListA(ListA2 listA) {
		this.listA = listA;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}
