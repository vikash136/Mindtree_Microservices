package com.mindtree.entity;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "bowling", "batting" })
public class Data {

	@JsonProperty("Bowling")
	private Bowling bowling;

	@JsonProperty("Batting")
	private Batting batting;

	@JsonIgnore
	private Map<String, Object> additionPropeties = new HashMap<String, Object>();

	@JsonProperty("Bowling")
	public Bowling getBowling() {
		return bowling;
	}

	@JsonProperty("Bowling")
	public void setBowling(Bowling bowling) {
		this.bowling = bowling;
	}

	@JsonProperty("Batting")
	public Batting getBatting() {
		return batting;
	}

	@JsonProperty("Batting")
	public void setBatting(Batting batting) {
		this.batting = batting;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionPropeties() {
		return additionPropeties;
	}

	@JsonAnyGetter
	public void setAdditionPropeties(Map<String, Object> additionPropeties) {
		this.additionPropeties = additionPropeties;
	}

}
