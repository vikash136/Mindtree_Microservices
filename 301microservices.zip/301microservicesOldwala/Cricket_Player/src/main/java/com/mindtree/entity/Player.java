package com.mindtree.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Player {

	@Id
	private int playerId;
	private String name;
	private String category;
	private int numOfMatchesPlayed;
	private int fifties;
	private int hundreds;
	private int wickets;
	
	public Player() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Player(int playerId, String name, String category, int numOfMatchesPlayed, int fifties, int hundreds,
			int wickets) {
		this.playerId = playerId;
		this.name = name;
		this.category = category;
		this.numOfMatchesPlayed = numOfMatchesPlayed;
		this.fifties = fifties;
		this.hundreds = hundreds;
		this.wickets = wickets;
	}
	
	public int getPlayerId() {
		return playerId;
	}
	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public int getNumOfMatchesPlayed() {
		return numOfMatchesPlayed;
	}
	public void setNumOfMatchesPlayed(int numOfMatchesPlayed) {
		this.numOfMatchesPlayed = numOfMatchesPlayed;
	}
	public int getFifties() {
		return fifties;
	}
	public void setFifties(int fifties) {
		this.fifties = fifties;
	}
	public int getHundreds() {
		return hundreds;
	}
	public void setHundreds(int hundreds) {
		this.hundreds = hundreds;
	}
	public int getWickets() {
		return wickets;
	}
	public void setWickets(int wickets) {
		this.wickets = wickets;
	}
	
}